How do I approach designing software?
I think about what would be the most practical method, and what uses the final product would have.

What new design skills has your work on the project helped you to craft?
This project let me learn the in's and out's of OpenGL and how to use the basics of it to create a scene.

What design process did you follow for your project work?
Modeling, coloring, moving the camera, texturing, and lighting.

How could tactics from your design approach be applied in future work?
Now that I have some experience with OpenGL, I can hopefully take up less time researching how it works.

How do I approach developing programs?
I first need to know the requirements, then from there I can devise a plan of what tools I'll need.

What new development strategies did you use while working on your 3D scene?
I re-used textures already within the files as a means of saving on memory as some of those textures would already fit the scene well.

How did iteration factor into your development?
Running the program after each change to make sure it was implemented correctly.

How has your approach to developing code evolved throughout the milestones, which led you to the project’s completion?
I can now quickly add or adjust objects as apposed to the speed at which I could do that in the first modules.

How can computer science help me in reaching my goals?
Computer Science is the best fit field for learning about programming. It teaches not just surface level code but the deep roots of all sorts of topics related to programming and software development.

How do computational graphics and visualizations give you new knowledge and skills that can be applied in your future educational pathway?
I appreciate finally taking a course in something like this. Now I finally have a feel of how modeling works through code. This will likely connect to another course I take in the near future.

How do computational graphics and visualizations give you new knowledge and skills that can be applied in your future professional pathway?
I can see myself working with all different flavors of software and coding languages and this helps me put some experience to my name.
