import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

    // test to create contact
    @Test
    void testContactServiceAddContact() {
        ContactService.addContact("1738", "Steve", "Fox", "4322210563", "60 Roberts Ave. Mount Laurel, NJ 08054");
        assertTrue(ContactService.contactList.get(0).getId().equals("1000000002"));
        assertTrue(ContactService.contactList.get(0).getFirstName().equals("Steve"));
        assertTrue(ContactService.contactList.get(0).getLastName().equals("Fox"));
        assertTrue(ContactService.contactList.get(0).getNumber().equals("4322210563"));
        assertTrue(ContactService.contactList.get(0).getAddress().equals("60 Roberts Ave. Mount Laurel, NJ 08054"));
    }


    // Test confirms contact deletion
    @Test
    void testContactServiceDeleteContact() {
        ContactService.addContact("1738", "Steve", "Fox", "4322210563", "60 Roberts Ave. Mount Laurel, NJ 08054");
        int sizeBeforeDelete = ContactService.contactList.size();
        ContactService.deleteContact("1000000003");
        int sizeAfterDelete = ContactService.contactList.size();
        assertTrue(sizeAfterDelete == sizeBeforeDelete - 1);
        assertTrue(ContactService.searchContact("1000000003") == -1);
    }


    // Test updates first name
    @Test
    void testContactServiceUpdateFirstName() {
        ContactService.addContact("Paul", "Phoenix", "4322210563", "9711 Manchester Ave. Aliquippa, PA 15001");
        int lastIndex = ContactService.contactList.size() - 1;
        ContactService.updateFirstName("1000000003", "Bob");
        assertTrue(ContactService.contactList.get(lastIndex).getFirstName().equals("Bob"));
    }


    // confirms unique ID
    @Test
    void testContactServiceUniqueId() {
        Contact newContact = new Contact("16482", "Leon", "Kennedy", "4322210563", "Original Contact Address");
        ContactService.addContact(newContact);
        Contact duplicateId = new Contact("16482", "Leon", "Kennedy", "4322210563", "Duplicate Contact Address");
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            ContactService.addContact(duplicateId);
        }, "Adding contact with duplicate ID should throw IllegalArgumentException");
    }

}
