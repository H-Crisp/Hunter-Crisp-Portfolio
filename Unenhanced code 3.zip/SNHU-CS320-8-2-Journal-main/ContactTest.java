import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {

    @Test
    void testContactCreation() {
        // tests contact
        Contact newContact = new Contact("1738", "Steve", "Fox", "4322210563", "60 Roberts Ave. Mount Laurel, NJ 08054");
        assertEquals("Steve", newContact.getFirstName());
        assertEquals("Fox", newContact.getLastName());
        assertEquals("1738", newContact.getId());
        assertEquals("4322210563", newContact.getNumber());
        assertEquals("60 Roberts Ave. Mount Laurel, NJ 08054", newContact.getAddress());
    }

    @Test
    void testContactTooLong() {
        // Tests for too long of an ID
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("10000000000", "Steve", "Fox", "4322210563", "60 Roberts Ave. Mount Laurel, NJ 08054");
        });
    }

    // function to add more tests

    @Test
    void testSetFirstName() {
        // Test fName setter method
        Contact newContact = new Contact("556", "Nina", "Williams", "4322210563", "new address");
        newContact.setFirstName("Ashley");
        assertEquals("Ashley", newContact.getFirstName());
        
    }

}

