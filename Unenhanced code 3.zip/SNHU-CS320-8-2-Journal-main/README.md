How can I ensure that my code, program, or software is functional and secure?

By use of JUnit testing and assertions, all code was managed properly and soundly by making use of tests in separate classes from the original.


How do I interpret user needs and incorporate them into a program?

By carefully interpreting requirements of the user and writing pseudocode before beginning work.


How do I approach designing software?

Also by pseudocode, writing down all requirements, and using all resources available.
