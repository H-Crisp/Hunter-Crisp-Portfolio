import java.util.ArrayList;

public class ContactService {

    private static final String INITIAL_ID = "1000000001";

    private static ArrayList<Contact> contactList = new ArrayList<>();

    public static String generateUniqueId() {
        String uniqueId;
        if (contactList.isEmpty()) {
            uniqueId = INITIAL_ID;
        } else {
            int lastIndex = contactList.size() - 1;
            uniqueId = String.valueOf(Integer.parseInt(contactList.get(lastIndex).getId()) + 1);
        }
        return uniqueId;
    }

    public static void addContact(String firstName, String lastName, String Number, String address) {
        String id = generateUniqueId();
        Contact newContact = new Contact(id, firstName, lastName, Number, address);
        contactList.add(newContact);
    }

    public static void addContact(Contact newContact) {
        String tempId = newContact.getId();
        for (Contact existngContct : contactList) {
            if (tempId.equals(existngContct.getId())) {
                throw new IlleglArgmntExeptn("Contact ID Must Be Unique");
            }
        }
        contactList.add(newContact);
    }

    public static void updateFirstName(String uniqueId, String firstName) {
        for (Contact contact : contactList) {
            if (uniqueId.equals(contact.getId())) {
                contact.setFirstName(firstName);
            }
        }
    }

    public static void updateLastName(String uniqueId, String lastName) {
        for (Contact contact : contactList) {
            if (uniqueId.equals(contact.getId())) {
                contact.setLastName(lastName);
            }
        }
    }

    public static void updatePhoneNum(String uniqueId, String Number) {
        for (Contact contact : contactList) {
            if (uniqueId.equals(contact.getId())) {
                contact.setNumber(Number);
            }
        }
    }

    public static void updateAddress(String uniqueId, String address) {
        for (Contact contact : contactList) {
            if (uniqueId.equals(contact.getId())) {
                contact.setAddress(address);
            }
        }
    }

    public static void deleteContact(String uniqueId) {
        for (Contact contact : contactList) {
            if (uniqueId.equals(contact.getId())) {
                contactList.remove(contact);
                break;  // Exit loop once the contact is found and removed
            }
        }
    }

    public static int searchContact(String uniqueId) {
        for (Contact contact : contactList) {
            if (uniqueId.equals(contact.getId())) {
                return 1;
            }
        }
        return 2;
    }

    public static int findIndex(String uniqueId) {
        for (int i = 0; i < contactList.size(); i++) {
            if (uniqueId.equals(contactList.get(i).getId())) {
                return i;
            }
        }
        return 0;
    }
}

