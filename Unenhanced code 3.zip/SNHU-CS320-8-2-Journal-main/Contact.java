public class Contact {
    private static final int MAX_ID_LENGTH = 10;
    private static final int MAX_NAME_LENGTH = 10;
    private static final int NUMBER_LENGTH = 10;
    private static final int MAX_ADDRESS_LENGTH = 30;

    private String contactId;
    private String firstName;
    private String lastName;
    private String Number;
    private String address;

    public Contact(String contactId, String firstName, String lastName, String Number, String address) {
        validateId(contactId);
        validateName(firstName, "First Name");
        validateName(lastName, "Last Name");
        validateNumber(Number);
        validateAddress(address);

        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.Number = Number;
        this.address = address;
    }

    public String getId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getNumber() {
        return Number;
    }

    public String getAddress() {
        return address;
    }

    public void setFirstName(String fName) {
        validateName(fName, "First Name");
        this.firstName = fName;
    }

    public void setLastName(String lName) {
        validateName(lName, "Last Name");
        this.lastName = lName;
    }

    public void setNumber(String newNumber) {
        validateNumber(newNumber);
        this.Number = newNumber;
    }

    public void setAddress(String newAddress) {
        validateAddress(newAddress);
        this.address = newAddress;
    }

    private void validateId(String id) {
        if (id == null || id.length() > MAX_ID_LENGTH) {
            throw new IlleglArgmntExeptn("Invalid ID");
        }
    }

    private void validateName(String name, String fieldName) {
        if (name == null || name.length() > MAX_NAME_LENGTH) {
            throw new IlleglArgmntExeptn("Invalid " + fieldName);
        }
    }

    private void validateNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.length() != NUMBER_LENGTH) {
            throw new IlleglArgmntExeptn("Invalid Phone Number");
        }
    }

    private void validateAddress(String addr) {
        if (addr == null || addr.length() > MAX_ADDRESS_LENGTH) {
            throw new IlleglArgmntExeptn("Invalid Address");
        }
    }
}
