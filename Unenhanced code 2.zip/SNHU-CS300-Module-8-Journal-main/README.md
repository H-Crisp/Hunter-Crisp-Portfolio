What was the problem you were solving in the projects for this course?

Sorting algorithms using methods of vector sorting, hash tables, and binary search trees in code and pseudocode formats.


How did you approach the problem? Consider why data structures are important to understand.

I approached the problem by using what I have learned and my available resources to tackle the problem. Different data structures are important for their own unique purposes,
though sometimes it can be left up to preference.


How did you overcome any roadblocks you encountered while going through the activities or project?

Roadblocks are bound to happen when learning code, so what I had to do was take a step back and make sure I learned all the concepts right, and do some outside research.


How has your work on this project expanded your approach to designing software and developing programs?

I feel like since learning these sorting methods that my knowledge on coding is evergrowing, and more doors have been opened to possibility.


How has your work on this project evolved the way you write programs that are maintainable, readable, and adaptable?

Programs that utilize these methods are going to be much, much more readable especially when dealing with lots more variables.
