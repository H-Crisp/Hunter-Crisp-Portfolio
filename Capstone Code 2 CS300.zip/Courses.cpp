#include <iostream>
#include <regex>
#include "Courses.h"

// constuctor
Courses::Courses() {
	root = nullptr;
}

// destructor
Courses::~Courses() {
	destroyRecurs(root);
}

// traversal in order
void Courses::InOrder() {
	inOrder(root);
}

// traversal in post-order
void Courses::PostOrder() {
	postOrder(root);
}

// traversal in pre-order
void Courses::PreOrder() {
	preOrder(root);
}

// method for inserting a course
void Courses::Insert(Course course) {
	if (root == nullptr) {
		root = new Node(course);
	}
	else {
		this->addNode(root, course);
	}
}

// method for course removal
void Courses::Remove(std::string courseId) {
	this->removeNode(root, courseId);
}

// course search method
Course Courses::Search(std::string courseId) {
	// convert courseID to upper case for comparison
	transform(courseId.begin(), courseId.end(), courseId.begin(), ::toupper);
	Node* cur = root;
	while (cur != nullptr) {
		if (cur->course.getCourseId().compare(courseId) == 0) {
			return cur->course;
		}
		// if course < current node then traverse left
		else if (courseId.compare(cur->course.getCourseId()) < 0) {
			cur = cur->left;
		}
		// else traverse right
		else {
			cur = cur->right;
		}
	}
	Course course;
	return course;
}

// add course to a node
void Courses::addNode(Node* node, Course course) {
	// if node is smaller, add to the left
	if (node != nullptr && (node->course.getCourseId().compare(course.getCourseId()) > 0)) {
		if (node->left == nullptr) {
			// this node becomes left if no left node already
			node->left = new Node(course);
			return;
		}
		else {
			this->addNode(node->left, course);
		}
	}
	
	else if (node != nullptr && (node->course.getCourseId().compare(course.getCourseId()) < 0)) {
		if (node->right == nullptr) {
			// this node becomes right if no right node already
			node->right = new Node(course);
			return;
		}
		else {
			this->addNode(node->right, course);
		}
	}
}

void Courses::destroyRecurs(Node* node) {
	// destructor for child nodes if node != nullptr
	if (node != nullptr) {
		destroyRecurs(node->left);
		destroyRecurs(node->right);
		delete node;
		node = nullptr;
	}
}

// in order
void Courses::inOrder(Node* node) {
	// if node != null ptr
	if (node != nullptr) {
		inOrder(node->left);
		// output courseID and courseName
		std::cout << node->course.getCourseId() << ", "
			<< node->course.getCourseName() << std::endl;
		inOrder(node->right);
	}
}

// post order
void Courses::postOrder(Node* node) {
	// if node != nullptr
	if (node != nullptr) {
		postOrder(node->left);
		postOrder(node->right);
		// output courseID and courseName
		std::cout << node->course.getCourseId() << ", "
			<< node->course.getCourseName() << std::endl;
	}
}

// pre order
void Courses::preOrder(Node* node) {
	// if node != nullptr
	if (node != nullptr) {
		// output courseID and courseName
		std::cout << node->course.getCourseId() << ", "
			<< node->course.getCourseName() << std::endl;
		preOrder(node->left);
		preOrder(node->right);
	}
}

Node* Courses::removeNode(Node* node, const std::string courseId) {
	if (node == nullptr) {
		return node;
	}
	// if course < current node then traverse left
	else if (courseId.compare(node->course.getCourseId()) < 0) {
		node->left = removeNode(node->left, courseId);
	}
	// else if course > current node then traverse right
	else if (courseId.compare(node->course.getCourseId()) > 0) {
		node->right = removeNode(node->right, courseId);
	}
	// else match found
	else {
		// leaf node
		if (node->left == nullptr && node->right == nullptr) {
			delete node;
			node = nullptr;
		}
		// else if left child
		else if (node->left != nullptr && node->right == nullptr) {
			Node* tmp = node;
			node = node->left;
			delete tmp;
			tmp = nullptr;
		}
		// else if right child
		else if (node->left == nullptr && node->right != nullptr) {
			Node* tmp = node;
			node = node->right;
			delete tmp;
			tmp = nullptr;
		}
		// else both child
		else {
			// find the minimum of the right subtree nodes for binary search tree
			Node* tmp = node;
			while (tmp->left != nullptr) {
				tmp = tmp->left;
			}
			node->course = tmp->course;
			node->right = removeNode(node->right, tmp->course.getCourseId());
		}
	}
	return node;
}