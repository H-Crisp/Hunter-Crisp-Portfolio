#ifndef projCourse
#define projCourse

#include <string>
#include <vector>

class Course {
	
private:
	std::string courseId;
	std::string courseName;
	std::vector<std::string> coursePrereq;
	
public:
	Course() = default;
	Course(std::string& id, std::string& name, std::vector<std::string>& prereq);
	std::string getCourseId();
	std::string getCourseName();
	std::vector<std::string> getCoursePrereq();
	std::string courseToString();
};

#endif