#include <iostream>
#include <fstream>
#include <sstream>
#include <regex>
#include "Courses.h"

//************************************************
// This project uses the binary search tree method 
//************************************************


// The following method diplays course info into console

void displayCourse(Course course) {
	std::vector<std::string> coursePrereq = course.getCoursePrereq();
	std::string prereq;

	// Method to format prerequisites
	if (coursePrereq.size() == 1) {
		prereq = course.getCoursePrereq()[0];
	}
	else if (coursePrereq.size() > 1) {
		for (int i = 0; i < coursePrereq.size() - 1; i++) {
			prereq += coursePrereq[i] + ", ";
		}
		prereq += coursePrereq.back();
	}
	else {
		prereq = "None.";
	}

	// print course details
	std::cout << course.getCourseId() << ", "
		<< course.getCourseName() << std::endl;
	std::cout << "Prerequisites: " << prereq << std::endl;
}



// load input file for courses
void loadCourses(const std::string& inputFilePath, Courses* coursesBst) {
	std::cout << "Loading input file " << "\"" << inputFilePath << "\"..." << std::endl;

	std::ifstream file(inputFilePath);
	std::string currentLine;
	try {
		while (std::getline(file, currentLine)) {
			std::stringstream ss(currentLine);
			std::string word, id, name;
			std::vector<std::string> prereq;
			int index = 0;
			while (!ss.eof()) {
				getline(ss, word, ',');
				word = std::regex_replace(word, std::regex(R"(\r\n|\r|\n)"), "");
				if (index == 0) {
					id = word;
				}
				else if (index == 1) {
					name = word;
				}
				else {
					prereq.push_back(word);
				}
				index++;
			}
			// add a data structure to courses
			Course course = Course(id, name, prereq);
			// add to tree
			coursesBst->Insert(course);
		}
	}
	catch (std::ifstream::failure& e) {
		std::cerr << e.what() << std::endl;
	}

	file.close();
}



int main() {
	// search tree to hold all the courses
	Courses* coursesBst;
	coursesBst = new Courses();
	Course course;
	std::string inputPath, courseKey;

	std::cout << "<*===*===*===*===*===*===*===*===*===*===*===*===*===*===*>" << std::endl;
	std::cout << "Welcome to the course planner." << std::endl;
	std::cout << "Please select one of the following options by typing a number and\npressing the \"Enter\" key." << std::endl;
	std::cout << "**YOU MUST FIRST LOAD A DATA STRUCTURE TO DISPLAY COURSES**" << std::endl;
	std::cout << "<*===*===*===*===*===*===*===*===*===*===*===*===*===*===*>" << std::endl << std::endl;


	int choice = 0;
	while (choice != 9) { //while loop that returns unless the selection is "9"
		std::cout << "  1. Load Data Structure." << std::endl;
		std::cout << "  2. See Course List." << std::endl;
		std::cout << "  3. See Course Prerequisites." << std::endl;
		std::cout << "  9. Exit." << std::endl << std::endl;
		std::cout << "> What would you like to do? ";
		std::cin >> choice;

		switch (choice) { //case statements for each option
		case 1:
			std::cout << "Selected \"Load Data Structure\" \n";
			std::cout << "> Enter the path to the input file (Example: \"courseList.txt\"):  ";
			std::cin >> inputPath;
			// Complete the method call to load the courses
			loadCourses(inputPath, coursesBst);
			break;
		case 2:
			std::cout << "Selected \"Print Course List\"" << std::endl;
			std::cout << "Here is a sample schedule:" << std::endl << std::endl;
			// Prints all courses read
			coursesBst->InOrder(); 
			std::cout << std::endl;
			break;
		case 3:
			std::cout << "Selected \"Print Course Prerequisites\"" << std::endl;
			std::cout << "What course do you want to know about? \n> Enter a course ID (Example: CSCI200). ";
			std::cin >> courseKey;
			course = coursesBst->Search(courseKey);

			//fetches prerequisites depending on if the course ID is found
			if (!course.getCourseId().empty()) {
				std::cout << std::endl;
				displayCourse(course);
			}
			else {
				std::cout << std::endl; 
				std::cout << "Course Id \"" << courseKey << "\" not found. Make sure the input file name or course ID is valid!" << std::endl;
			}
			break;
		case 9:
			//quit statement
			std::cout << "Thank you for using the Course Planner! Good bye." << std::endl;
			break;
		default:
			//the default if an invalid option is entered
			std::cout << choice << " is not a valid option. Try using 1, 2, 3, or 9." << std::endl;
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			break;
		}
		std::cout << "<*===*===*===*===*===*===*===*===*===*===*===*===*===*===*>" << std::endl; 
		std::cout << std::endl;
	}

	return 0;
}
