#include "Course.h"

Course::Course(std::string& id, std::string& name, std::vector<std::string>& prerequisites) {
	this->courseId = id;
	this->courseName = name;
	this->coursePrereq = prerequisites;
}

// Gets the course id
std::string Course::getCourseId() {
	return this->courseId;
}

// Gets the course name
std::string Course::getCourseName() {
	return this->courseName;
}

// Gets the list of course prerequisites
std::vector<std::string> Course::getCoursePrereq() {
	return this->coursePrereq;
}

// return string with courseId and courseName
std::string Course::courseToString() {
	return this->courseId + ", " + this->courseName;
}